# A little place made for you ♡
A romantic interactive GitHub Pages website using your uploaded personal video clips, your bouquet/crown artwork, and your uploaded song.

## Publish the complete website
1. Create a GitHub repository.
2. Upload `index.html` **and the entire `assets` folder** to the repository root. Do not upload only the HTML file.
3. Open Settings → Pages.
4. Choose Deploy from a branch → `main` → `/ (root)` → Save.
5. Share the published Pages URL.

## Music
The uploaded song is set to autoplay at 20% volume. Browsers often block audible autoplay until a visitor interacts with the page, so pressing the opening “Open your little love sanctuary” button starts it at 20% volume if autoplay was blocked.

## Privacy and copyright
If the repository is public, its personal video clips and images can be viewed or downloaded by anyone. The song may be subject to copyright restrictions on public hosting.
